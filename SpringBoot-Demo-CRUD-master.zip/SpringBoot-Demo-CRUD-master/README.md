# SpringBoot-Demo-CRUD
课程地址：https://www.bilibili.com/video/BV15b4y1a7yG?share_source=copy_web  
文档说明：https://www.yuque.com/docs/share/4982b5b4-9a61-46f0-816e-cc0f6ba0d3d0?# 《简单的CRUD案例》  
代码对应P29-P50，删除了冗余部分代码，命名有些不一样。
## 数据库文件
db/文件夹下
### 项目预览图
![preview](https://raw.githubusercontent.com/SiQuan-Wen/SpringBoot-Demo-CRUD/master/images/preview.jpeg)
